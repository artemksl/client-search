"""Offline ChatGPT fixtures."""
