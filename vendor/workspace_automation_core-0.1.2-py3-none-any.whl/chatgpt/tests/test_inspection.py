"""Offline reuse acceptance: real Chromium, intercepted fixture, real journal."""
from dataclasses import replace
from contextlib import ExitStack
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from playwright.sync_api import sync_playwright

from automation_core.contracts import ExpectedScope, Finished, Outcome, StopReason
from automation_core.diagnostics.failure_capture import FailureCapture
from automation_core.storage.memory import AccountMemory, TransitionDenied
from chatgpt.inspection import compose_inspection
from automation_core.storage.locking import resource_lock
from automation_core.storage.models import NeedsAttention


class InspectionReuseTests(unittest.TestCase):
    def test_namespaced_workflow_runs_and_resumes_without_browser_input(self):
        profile = 'c' * 32
        identity = 'chatgpt:fixture-user'
        scope = ExpectedScope(sha256(identity.encode()).hexdigest(), identity, profile)
        with TemporaryDirectory() as directory, sync_playwright() as playwright, ExitStack() as cleanup:
            root = Path(directory)
            with resource_lock(root, profile, identity) as owner:
                with self.assertRaises(NeedsAttention):
                    with resource_lock(root, 'd' * 32, identity):
                        self.fail('The same account must stay exclusively owned.')
                AccountMemory.initialize_store(root, scope, owner)
                memory = AccountMemory.open(root, scope, owner)
                cleanup.callback(memory.close)
                with self.assertRaises(TransitionDenied):
                    AccountMemory.open(root, replace(scope, expected_account_id='chatgpt:other'), owner)

                browser = playwright.chromium.launch(headless=True)
                cleanup.callback(browser.close)
                context = browser.new_context()
                context.route('**/*', lambda route: route.fulfill(status=200,
                    content_type='text/html', body='<!doctype html><title>Local ChatGPT fixture</title>'
                    '<form data-chatgpt-composer><div data-composer-markdown '
                    'contenteditable="true" role="textbox" aria-label="Ask ChatGPT"></div></form>'))
                page = context.new_page()
                page.goto('https://chatgpt.com/')
                session = SimpleNamespace(context=context, failure_page=page)

                def compose(workflow, create=True):
                    session.failure_capture = FailureCapture(root / 'captures',
                        profile_uuid=profile, workflow_id=workflow)
                    return compose_inspection(session=session, page=page, ownership=owner,
                        memory=memory, workflow_id=workflow, create=create)

                app = compose('composer-ready')
                with patch.object(app.driver, '_dispatch', side_effect=AssertionError('Unexpected input')):
                    result = app.run()
                self.assertEqual(result.outcome, Outcome.CONFIRMED, result)
                self.assertIsNone(result.stop_reason, result)
                self.assertIsInstance(memory.load_checkpoint('composer-ready').main, Finished)
                self.assertEqual(memory.pending_for(scope), ())
                self.assertEqual(memory._read('SELECT SUM(effect_intents_used) FROM operations')[0][0], 0)
                self.assertTrue(list((root / 'captures').rglob('page.html')))

                # Reopening the actual journal consumes its committed result.
                memory.close()
                memory = AccountMemory.open(root, scope, owner)
                cleanup.callback(memory.close)
                resumed = compose('composer-ready', create=False)
                with patch.object(page, 'locator', side_effect=AssertionError('Completed read was replayed')):
                    result = resumed.run()
                self.assertEqual(result.outcome, Outcome.CONFIRMED, result)

                page.locator('[data-composer-markdown]').evaluate('(node) => node.remove()')
                held = compose('composer-missing').run()
                self.assertEqual(held.stop_reason, StopReason.PAGE_NOT_READY, held)
                page.goto('https://example.com/')
                wrong_origin = compose('wrong-origin').run()
                self.assertEqual(wrong_origin.stop_reason, StopReason.PROVIDER_ORIGIN_MISMATCH)
                self.assertEqual(memory.pending_for(scope), ())
                self.assertEqual(len(context.pages), 1)
                memory.close()
                browser.close()


if __name__ == '__main__':
    unittest.main()
