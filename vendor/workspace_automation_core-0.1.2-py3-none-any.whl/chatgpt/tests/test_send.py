"""Small offline browser/journal checks using the gpt-send DOM attributes."""
from contextlib import contextmanager
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from playwright.sync_api import sync_playwright

from automation_core.contracts import ExpectedScope, Finished, Outcome, PrivateInputRef, ResolvedPrivateInput, SensitiveValue
from automation_core.storage.locking import resource_lock
from automation_core.storage.memory import TransitionDenied
from chatgpt.memory import AccountMemory
from chatgpt.inspection import compose_inspection
from chatgpt.page import COMPOSER, text_digest
from chatgpt.send import compose_send, read_reply


PROMPT = 'A synthetic offline prompt.'
PROMPT_REF = PrivateInputRef('fixture', 'prompt', 'v1')
FIXTURE = Path(__file__).parent / 'fixtures' / 'send.html'


@contextmanager
def fixture():
    with TemporaryDirectory() as directory, sync_playwright() as playwright:
        root = Path(directory)
        identity, profile = 'chatgpt:send-fixture', 'c' * 32
        scope = ExpectedScope(sha256(identity.encode()).hexdigest(), identity, profile)
        with resource_lock(root, profile, identity) as owner:
            AccountMemory.initialize_store(root, scope, owner)
            memory = AccountMemory.open(root, scope, owner)
            browser = playwright.chromium.launch(headless=True)
            try:
                context = browser.new_context()
                context.route('**/*', lambda route: route.fulfill(status=200,
                    content_type='text/html', body=FIXTURE.read_text()))
                page = context.new_page()
                page.goto('https://chatgpt.com/')
                session = SimpleNamespace(context=context, failure_page=page)

                def compose(workflow, create=True, timeout=3., journal=None):
                    return compose_send(session=session, page=page, ownership=owner,
                        memory=memory if journal is None else journal,
                        workflow_id=workflow, prompt_ref=PROMPT_REF,
                        prompt_sha256=text_digest(PROMPT), private_inputs=lambda ref:
                            ResolvedPrivateInput(ref, SensitiveValue(PROMPT)),
                        reply_timeout_s=timeout, create=create)
                yield SimpleNamespace(root=root, scope=scope, owner=owner, memory=memory,
                    page=page, session=session, compose=compose)
            finally:
                memory.close()
                browser.close()


class SendTests(unittest.TestCase):
    def test_captured_composer_and_send_reply_reopen(self):
        with fixture() as f:
            inspected = compose_inspection(session=f.session, page=f.page, ownership=f.owner,
                memory=f.memory, workflow_id='inspect', create=True).run()
            self.assertEqual(inspected.outcome, Outcome.CONFIRMED, inspected)
            result = f.compose('send').run()
            self.assertEqual(result.outcome, Outcome.CONFIRMED, result)
            self.assertIsNone(result.stop_reason, result)
            self.assertEqual(read_reply(f.memory, 'send'), 'Synthetic completed reply.')
            self.assertEqual(f.page.evaluate('window.sendCount'), 1)
            self.assertEqual(f.memory.pending_for(f.scope), ())
            self.assertIsInstance(f.memory.load_checkpoint('send').main, Finished)
            # Step 2 of the capture can already be present when the caller attaches.
            f.page.goto('https://chatgpt.com/')
            f.page.locator(COMPOSER).fill(PROMPT)
            prefilled = f.compose('prefilled')
            dispatch = prefilled.driver._dispatch

            def no_refill(request, *args, **kwargs):
                self.assertNotEqual(request.kind, 'fill', 'A matching draft was replaced')
                return dispatch(request, *args, **kwargs)

            with patch.object(prefilled.driver, '_dispatch', side_effect=no_refill):
                prefilled_result = prefilled.run()
                self.assertEqual(prefilled_result.outcome, Outcome.CONFIRMED, prefilled_result)
                self.assertIsNone(prefilled_result.stop_reason, prefilled_result)
            self.assertEqual(f.page.evaluate('window.sendCount'), 1)
            f.memory.close()
            reopened = AccountMemory.open(f.root, f.scope, f.owner)
            try:
                app = compose_send(session=f.session, page=f.page, ownership=f.owner,
                    memory=reopened, workflow_id='send', prompt_ref=PROMPT_REF,
                    prompt_sha256=text_digest(PROMPT), private_inputs=lambda ref:
                        (_ for _ in ()).throw(AssertionError('Completed prompt was read again')),
                    reply_timeout_s=3., create=False)
                with patch.object(f.page, 'locator', side_effect=AssertionError('Completed send was replayed')):
                    self.assertEqual(app.run().outcome, Outcome.CONFIRMED)
                self.assertEqual(read_reply(reopened, 'send'), 'Synthetic completed reply.')
                with self.assertRaises(TransitionDenied):
                    compose_send(session=f.session, page=f.page, ownership=f.owner,
                        memory=reopened, workflow_id='send', prompt_ref=PROMPT_REF,
                        prompt_sha256=text_digest('Changed prompt'), private_inputs=lambda ref: None,
                        reply_timeout_s=3., create=False)
            finally:
                reopened.close()

    def test_unknown_submission_stays_pending_without_resend(self):
        with fixture() as f:
            # The API returns, but the expected user/turn evidence never appears.
            f.page.evaluate("document.querySelector('form').addEventListener('submit', () => "
                "document.querySelector('#conversation').replaceChildren())")
            app = f.compose('uncertain')
            submit = app.invocations.block('chatgpt.send').pages[0].steps[1].action
            submit.observation_s = .5  # Keep this deliberate missing-result fixture short.
            result = app.run()
            self.assertEqual(result.outcome, Outcome.UNKNOWN, result)
            self.assertEqual(f.page.evaluate('window.sendCount'), 1)
            self.assertEqual(len(f.memory.pending_for(f.scope)), 1)
            f.memory.close()
            reopened = AccountMemory.open(f.root, f.scope, f.owner)
            try:
                resumed = f.compose('uncertain', create=False, journal=reopened)
                with patch.object(resumed.driver, '_dispatch', side_effect=AssertionError('Uncertain send repeated')):
                    resumed.run()
                self.assertEqual(len(reopened.pending_for(f.scope)), 1)
            finally:
                reopened.close()
            self.assertEqual(f.page.evaluate('window.sendCount'), 1)

    def test_disappearing_stop_does_not_complete_a_partial_reply(self):
        with fixture() as f:
            f.page.evaluate("window.holdReply = true; document.querySelector('form').addEventListener('submit', "
                "() => document.querySelector('#controls').replaceChildren())")
            result = f.compose('partial', timeout=1.).run()
            self.assertNotEqual(result.outcome, Outcome.CONFIRMED, result)
            with self.assertRaises(TransitionDenied):
                read_reply(f.memory, 'partial')
            self.assertEqual(f.page.evaluate('window.sendCount'), 1)

    def test_changed_draft_is_rechecked_before_native_send(self):
        with fixture() as f:
            app = f.compose('changed')
            submit = app.invocations.block('chatgpt.send').pages[0].steps[1].action
            original = submit.dispatch_assessment

            def changed(value, binding, ctx, request, deadline):
                assessment = original(value, binding, ctx, request, deadline)
                # Changes after the action's initial precondition; final verifier sees it.
                f.page.locator(COMPOSER).fill('A different draft')
                return assessment

            submit.dispatch_assessment = changed
            result = app.run()
            self.assertNotEqual(result.outcome, Outcome.CONFIRMED, result)
            self.assertEqual(f.page.evaluate('window.sendCount'), 0)
            self.assertEqual(f.memory.pending_for(f.scope), ())


if __name__ == '__main__':
    unittest.main()
