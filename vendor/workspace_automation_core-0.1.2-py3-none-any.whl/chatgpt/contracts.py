"""ChatGPT's small durable records, registered with the shared closed codec."""
from dataclasses import dataclass
import re

from automation_core import contracts as shared
from automation_core.storage.persistence import PersistenceError, register_records


@dataclass(frozen=True)
class ChatGPTSendInputs:
    prompt_ref: shared.PrivateInputRef
    prompt_sha256: str
    reply_timeout_s: float


@dataclass(frozen=True)
class ChatGPTSubmittedOutput:
    conversation_path: str
    turn_key: str
    prompt_sha256: str


@dataclass(frozen=True)
class ChatGPTReplyOutput:
    conversation_path: str
    turn_key: str
    message_id: str
    reply_file: str
    reply_sha256: str


def _validate(value):
    digest = getattr(value, 'prompt_sha256', getattr(value, 'reply_sha256', None))
    if not isinstance(digest, str) or not re.fullmatch(r'[0-9a-f]{64}', digest):
        raise PersistenceError()
    if type(value) is ChatGPTSendInputs:
        if not 1. <= value.reply_timeout_s <= 300.:
            raise PersistenceError()
    elif not re.fullmatch(r'/c/[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', value.conversation_path):
        raise PersistenceError()
    if type(value) is ChatGPTReplyOutput and not re.fullmatch(r'[0-9a-f]{64}\.json', value.reply_file):
        raise PersistenceError()


register_records(globals(),
    ('ChatGPTSendInputs', 'ChatGPTSubmittedOutput', 'ChatGPTReplyOutput'),
    {ChatGPTSendInputs: 'chatgpt_send_inputs.v1',
     ChatGPTSubmittedOutput: 'chatgpt_submitted.v1', ChatGPTReplyOutput: 'chatgpt_reply.v1'},
    {}, {}, {shared.PermittedInputs: (ChatGPTSendInputs, ChatGPTSubmittedOutput),
             shared.SafeOutput: (ChatGPTSubmittedOutput, ChatGPTReplyOutput)}, validator=_validate)
