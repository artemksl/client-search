"""ChatGPT result qualification over the unchanged shared journal transitions."""
from automation_core import contracts as c
from automation_core.storage.memory import AccountMemory as SharedAccountMemory, TransitionDenied
from chatgpt.contracts import ChatGPTSendInputs


class AccountMemory(SharedAccountMemory):
    def _satisfied_without_dispatch(self, cp, intent, result):
        # Only the matching local draft can satisfy preparation without input.
        # This permission never applies to Send or resolves an entered effect.
        original = self.workflow_inputs(cp.workflow_id)
        return super()._satisfied_without_dispatch(cp, intent, result) or (
            cp.definition_id == 'chatgpt.send' and cp.definition_version == 1
            and intent.step_id == 'chatgpt.send.fill'
            and intent.semantic_target == 'chatgpt.send.draft'
            and intent.effect_kind is c.EffectKind.REPEATABLE_PREPARATION
            and type(original) is ChatGPTSendInputs and intent.permitted_inputs == original
            and intent.private_inputs == (original.prompt_ref,)
            and result.outcome is c.Outcome.CONFIRMED and result.stop_reason is None
            and type(result.output) is c.EmptyPayload and result.receipt is None
            and bool(result.evidence_refs))

    def _validate_site_output(self, cp, result, intent):
        super()._validate_site_output(cp, result, intent)
        if (intent.step_id == 'chatgpt.send.fill' and result.receipt is None
                and result.outcome is c.Outcome.CONFIRMED):
            if not self._satisfied_without_dispatch(cp, intent, result):
                raise TransitionDenied(c.StopReason.INTENT_MISMATCH)
            proofs = self._proofs(cp, result)
            if not any(type(proof.details) is c.ObservationDetails
                       and proof.details.state == 'chatgpt_draft_already_matches' for proof in proofs):
                raise TransitionDenied(c.StopReason.INTENT_MISMATCH)
