"""One captured home → draft → send → completed reply flow on a borrowed tab."""
from hashlib import sha256
from pathlib import Path
import re

from automation_core.contracts import ActionRequest, EmptyPayload, OutputBinding, Outcome, StopReason, TargetRef
from automation_core.storage.memory import TransitionDenied
from automation_core.storage.persistence import validate
from automation_core.storage.private_files import atomic_json, private_directory, read_json, MAX_JSON_BYTES
from automation_core.workflow.blocks import ActionBlock, ActionPreconditionStop, PageBlock, RegisteredBlock, Step, observed_evidence
from automation_core.workflow.composition import compose_registered_workflow, merge_block_definitions
from automation_core.workflow.dispatch_policy import DispatchPurpose, ZeroSpendingDispatchPolicy
from automation_core.workflow.runtime import BlockInvocation
from automation_core.workflow.timing import ActionTiming, BudgetSpec
from chatgpt.contracts import ChatGPTReplyOutput, ChatGPTSendInputs, ChatGPTSubmittedOutput
from chatgpt.inspection import ChatGPTPage
from chatgpt.memory import AccountMemory as ChatGPTMemory
from chatgpt.page import COMPOSER, SEND, normalized_text, read_page, text_digest


BLOCK_ID = 'chatgpt.send'
CONVERSATION_PATH = r'/c/[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}'


def _state(binding, ctx, budget):
    return ctx.observations.observe_page(binding, read_page, deadline=budget.until)


def _hold(ctx, state):
    raise ActionPreconditionStop(observed_evidence(ctx, outcome=Outcome.NOT_RUN,
        state=state, stop=StopReason.PAGE_NOT_READY))


def _home(state):
    return state.path == '/' and state.composer_ready and not state.stopping and not state.turns


def _draft(inputs, state):
    return _home(state) and state.composer_digest == inputs.prompt_sha256 and state.send_ready


def _fill_precondition(inputs, binding, ctx, budget):
    state = _state(binding, ctx, budget)
    if _draft(inputs, state):
        return observed_evidence(ctx, outcome=Outcome.CONFIRMED,
            state='chatgpt_draft_already_matches', output=EmptyPayload())
    if not (_home(state) and state.composer_empty):
        _hold(ctx, 'chatgpt_empty_home_required')
    return True


def _fill_request(inputs, binding, ctx):
    value = ctx.private_inputs(inputs.prompt_ref)
    if not normalized_text(value.reveal()) or text_digest(value.reveal()) != inputs.prompt_sha256:
        value.clear()
        raise TransitionDenied(StopReason.INTENT_MISMATCH)
    return ActionRequest('fill', TargetRef(binding.view, COMPOSER), value)


def _filled(inputs, binding, ctx, budget):
    ready = _draft(inputs, _state(binding, ctx, budget))
    return observed_evidence(ctx, outcome=Outcome.CONFIRMED if ready else Outcome.UNKNOWN,
        state='chatgpt_draft_verified' if ready else 'chatgpt_draft_unverified',
        output=EmptyPayload() if ready else None, stop=None if ready else StopReason.PAGE_NOT_READY)


def _send_precondition(inputs, binding, ctx, budget):
    if not _draft(inputs, _state(binding, ctx, budget)):
        _hold(ctx, 'chatgpt_send_prerequisites_changed')
    return True


def _send_request(inputs, binding, ctx):
    return ActionRequest('click', TargetRef(binding.view, SEND))


def _submitted(inputs, binding, ctx, budget):
    state = _state(binding, ctx, budget)
    turn = state.turns[0] if len(state.turns) == 1 else None
    ready = (re.fullmatch(CONVERSATION_PATH, state.path) is not None
             and state.composer_ready and state.composer_empty and turn is not None
             and bool(turn.key) and turn.user_digest == inputs.prompt_sha256
             and turn.state in ('in_progress', 'complete'))
    output = ChatGPTSubmittedOutput(state.path, turn.key, inputs.prompt_sha256) if ready else None
    return observed_evidence(ctx, outcome=Outcome.CONFIRMED if ready else Outcome.UNKNOWN,
        state='chatgpt_submission_verified' if ready else 'chatgpt_submission_unverified',
        output=output, stop=None if ready else StopReason.PAGE_NOT_READY)


def _reply_inputs(inputs, progress):
    outputs = [action.output for action in progress.actions if type(action.output) is ChatGPTSubmittedOutput]
    if len(outputs) != 1:
        raise TransitionDenied(StopReason.PREREQUISITE_UNSATISFIED)
    return outputs[0]


def _reply_directory(memory):
    directory = Path(memory.path).parent.resolve() / 'chatgpt-replies'
    private_directory(directory)
    return directory


def _reply(submitted, binding, ctx, budget):
    state = _state(binding, ctx, budget)
    turns = [turn for turn in state.turns if turn.key == submitted.turn_key]
    turn = turns[0] if len(turns) == 1 and len(state.turns) == 1 else None
    correlated = (state.path == submitted.conversation_path and turn is not None
                  and turn.user_digest == submitted.prompt_sha256)
    ready = (correlated and not state.stopping and turn.state == 'complete'
             and bool(turn.message_id) and bool(normalized_text(turn.reply)))
    if not ready:
        return observed_evidence(ctx, outcome=Outcome.NOT_RUN,
            state='chatgpt_reply_in_progress' if correlated else 'chatgpt_reply_identity_changed',
            stop=StopReason.PAGE_NOT_READY if correlated else StopReason.IDENTITY_MISMATCH)
    ctx.ownership.assert_owned()
    filename = sha256(ctx.active_ticket.operation_id.encode()).hexdigest() + '.json'
    digest = sha256(turn.reply.encode()).hexdigest()
    # Text stays in the caller's private store; the journal contains only its reference.
    atomic_json(_reply_directory(ctx.memory) / filename,
        {'conversation_path': state.path, 'turn_key': turn.key,
         'message_id': turn.message_id, 'reply': turn.reply, 'reply_sha256': digest})
    output = ChatGPTReplyOutput(state.path, turn.key, turn.message_id, filename, digest)
    return observed_evidence(ctx, outcome=Outcome.CONFIRMED, state='chatgpt_reply_complete', output=output)


def compose_send(*, session, page, ownership, memory, workflow_id, prompt_ref,
                 prompt_sha256, private_inputs, reply_timeout_s=60., create=False, clock=None):
    """Borrow an already owned session. No login, tab discovery or profile launch.

    Fresh sends require an idle empty home page (or the exact already entered
    draft). The prompt ref/hash and timeout are frozen in the original workflow.
    Resume consumes saved results; uncertain effects retain the core's pending hold.
    """
    if not isinstance(memory, ChatGPTMemory):
        raise TypeError('The send flow requires chatgpt.memory.AccountMemory.')
    inputs = ChatGPTSendInputs(prompt_ref, prompt_sha256, float(reply_timeout_s))
    validate(inputs)
    fill = ActionBlock('fill', ActionTiming(.1, 5., 5., .2, .2), _fill_request, _filled,
        precondition=_fill_precondition, consequential=False,
        intent_inputs=lambda value: value, private_refs=lambda value: (value.prompt_ref,),
        semantic_target=BLOCK_ID + '.draft', allow_satisfied_precondition=True)
    send = ActionBlock('submit', ActionTiming(.1, 5., 10., .2, .2), _send_request, _submitted,
        precondition=_send_precondition, intent_inputs=lambda value: value,
        semantic_target=BLOCK_ID + '.message', observation_s=10.)
    reply = ActionBlock('reply', ActionTiming(0., 0., inputs.reply_timeout_s, .2, .2), None, _reply,
        intent_inputs=lambda value: value, semantic_target=BLOCK_ID + '.reply',
        observation_s=inputs.reply_timeout_s)
    stage = PageBlock(BLOCK_ID + '.page', (
        Step(fill, step_id=BLOCK_ID + '.fill'), Step(send, step_id=BLOCK_ID + '.submit'),
        Step(reply, bind_inputs=_reply_inputs, step_id=BLOCK_ID + '.reply')))
    block = RegisteredBlock(BLOCK_ID, (stage,), ChatGPTPage(page, BLOCK_ID), final=True,
        input_schema='chatgpt_send_inputs.v1',
        output_bindings=(OutputBinding('reply', 'chatgpt_reply.v1', BLOCK_ID + '.reply'),))
    definition = merge_block_definitions('chatgpt.send', 1, (block,))

    def assessment(source, kind, selector, verifier):
        def assess(value, binding, ctx, request, deadline):
            def verify(until):
                return (request.kind == kind and request.target == TargetRef(binding.view, selector)
                        and verifier(value, _state(binding, ctx, ctx.call_budget(until))))
            return ctx.executor.dispatch_policy.assessment(source, DispatchPurpose.MESSAGE_SUBMISSION,
                request, binding, ctx, deadline, verify=verify)
        return assess

    fill.dispatch_assessment = assessment(fill, 'fill', COMPOSER,
        lambda value, state: _home(state) and state.composer_empty)
    send.dispatch_assessment = assessment(send, 'click', SEND, _draft)
    app = compose_registered_workflow(session=session, ownership=ownership,
        memory=memory, private_inputs=private_inputs, definition=definition,
        invocations=(BlockInvocation(block, lambda outputs, ctx: inputs),),
        workflow_operation_id=workflow_id, workflow_inputs=inputs,
        allocation=BudgetSpec((stage.plan.cost_s() + 5.) / .7),
        clock=clock, create_workflow=create)
    if app.driver is not None:
        app.context.executor.dispatch_policy = ZeroSpendingDispatchPolicy(app.driver, (fill, send))
    return app


def read_reply(memory, workflow_id):
    """Read only an exact committed reply, verifying its private file on reopen."""
    memory.ownership.assert_owned()
    checkpoint = memory.load_checkpoint(workflow_id)
    refs = [ref for ref in checkpoint.output_refs
            if ref.output_key == 'reply' and ref.output_schema == 'chatgpt_reply.v1']
    if len(refs) != 1:
        raise TransitionDenied(StopReason.PREREQUISITE_UNSATISFIED)
    output = memory.resolve_output_ref(refs[0], workflow_id=workflow_id,
        producer_block_id=BLOCK_ID, producer_step_id=BLOCK_ID + '.reply', output_schema='chatgpt_reply.v1')
    saved = read_json(_reply_directory(memory) / output.reply_file, limit=MAX_JSON_BYTES)
    if (saved.get('conversation_path'), saved.get('turn_key'), saved.get('message_id'),
            saved.get('reply_sha256')) != (output.conversation_path, output.turn_key,
            output.message_id, output.reply_sha256) or not isinstance(saved.get('reply'), str):
        raise TransitionDenied(StopReason.INTENT_MISMATCH)
    if sha256(saved['reply'].encode()).hexdigest() != output.reply_sha256:
        raise TransitionDenied(StopReason.INTENT_MISMATCH)
    return saved['reply']
