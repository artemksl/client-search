"""Read the composer and turn markers observed in the gpt-send walkthrough."""
from dataclasses import dataclass, field
from hashlib import sha256
from urllib.parse import urlsplit


ORIGIN = 'https://chatgpt.com'
FORM = 'form[data-chatgpt-composer]'
COMPOSER = FORM + ' [data-composer-markdown][role="textbox"][contenteditable="true"]'
SEND = FORM + ' button[aria-label="Send"][type="submit"]'
STOP = FORM + ' button[aria-label="Stop"]'
TURNS = '[data-turn-key]'


def chatgpt_origin(url):
    parsed = urlsplit(url)
    return parsed.scheme == 'https' and parsed.netloc == 'chatgpt.com'


def normalized_text(text):
    # The rich editor adds an empty final paragraph; the submitted bubble does not.
    return text.replace('\r\n', '\n').strip()


def text_digest(text):
    return sha256(normalized_text(text).encode()).hexdigest()


@dataclass(frozen=True)
class Turn:
    key: str
    state: str | None
    user_digest: str | None
    message_id: str | None
    reply: str = field(repr=False)


@dataclass(frozen=True)
class PageState:
    path: str
    composer_ready: bool
    composer_empty: bool
    composer_digest: str | None
    send_ready: bool
    stopping: bool
    turns: tuple[Turn, ...]


def composer_ready(page, budget):
    """Read control readiness without reading the draft or conversation."""
    budget.checkpoint()
    if not chatgpt_origin(page.url):
        return False
    composer = page.locator(COMPOSER)
    return (page.locator(FORM).count() == 1 and composer.count() == 1
            and composer.is_visible() and composer.is_editable(timeout=budget.timeout_ms()))


def read_page(page, budget):
    """Bounded observations only; duplicate controls never qualify an action."""
    budget.checkpoint()
    if not chatgpt_origin(page.url):
        return PageState('', False, False, None, False, False, ())
    composer = page.locator(COMPOSER)
    ready = composer_ready(page, budget)
    text = composer.inner_text(timeout=budget.timeout_ms()) if ready else None
    send = page.locator(SEND)
    send_ready = (ready and send.count() == 1 and send.is_visible()
                  and send.is_enabled(timeout=budget.timeout_ms()))
    # Even an offscreen Stop means the current generation has not settled.
    stopping = page.locator(STOP).count() > 0
    turns = []
    for node in page.locator(TURNS).all():
        budget.checkpoint()
        user = node.locator('[data-user-message-bubble="true"]')
        state = node.locator('[data-talvt-turn-state]')
        body = node.locator('[data-markdown-copy="contents"][data-dil-source-message-id]')
        turns.append(Turn(node.get_attribute('data-turn-key'),
            state.get_attribute('data-talvt-turn-state') if state.count() == 1 else None,
            text_digest(user.inner_text(timeout=budget.timeout_ms())) if user.count() == 1 else None,
            body.get_attribute('data-dil-source-message-id') if body.count() == 1 else None,
            body.inner_text(timeout=budget.timeout_ms()) if body.count() == 1 else ''))
    budget.checkpoint()
    return PageState(urlsplit(page.url).path or '/', ready,
        text is not None and not normalized_text(text), text_digest(text) if text is not None else None,
        send_ready, stopping, tuple(turns))
