"""Read-only composer inspection on a caller-supplied ChatGPT tab.

Composer readiness is not evidence of account identity or authentication.
The caller supplies the existing owned session, state and selected page.
"""
from automation_core.workflow.blocks import ActionBlock, PageBlock, RegisteredBlock, Step, observed_evidence
from automation_core.workflow.composition import compose_registered_workflow, merge_block_definitions
from automation_core.contracts import EmptyPayload, NavigationResult, Outcome, PageBinding, StopReason
from automation_core.workflow.runtime import BlockInvocation
from automation_core.workflow.timing import ActionTiming, BudgetSpec
from chatgpt.page import COMPOSER, ORIGIN, chatgpt_origin, composer_ready


BLOCK_ID = 'chatgpt.inspect_composer'


class ChatGPTPage:
    """An explicit borrowed tab, without tab discovery or login side effects."""
    def __init__(self, page, component_id=BLOCK_ID):
        self.page = page
        self.component_id = component_id

    def ensure_entry(self, ctx):
        driver = ctx.observations
        ref = driver.bind_page(self.page)
        if not chatgpt_origin(driver.url(ref, deadline=ctx.budget.normal_until)):
            return NavigationResult(outcome=Outcome.NOT_RUN,
                                    stop_reason=StopReason.PROVIDER_ORIGIN_MISMATCH)
        return NavigationResult(outcome=Outcome.CONFIRMED,
            binding=PageBinding(ref, self.component_id, ORIGIN))


def _inspect(inputs, binding, ctx, budget):
    budget.checkpoint()

    def read(page, read_budget):
        return composer_ready(page, read_budget)

    ready = ctx.observations.observe_page(binding, read, deadline=budget.until)
    return observed_evidence(ctx,
        outcome=Outcome.CONFIRMED if ready else Outcome.NOT_RUN,
        state='chatgpt_composer_ready' if ready else 'chatgpt_composer_unavailable',
        output=EmptyPayload() if ready else None,
        stop=None if ready else StopReason.PAGE_NOT_READY)


def compose_inspection(*, session, page, ownership, memory, workflow_id,
                       create=False, clock=None):
    """Compose one saved read through the original driver, runner and journal.

    The composer selector comes from the gpt-send captures. Live compatibility
    remains to be verified on the user's selected browser.
    """
    action = ActionBlock('inspect', ActionTiming(0., 0., 3., .1, .1),
        None, _inspect, semantic_target=BLOCK_ID)
    stage = PageBlock(BLOCK_ID + '.page',
        (Step(action, step_id=BLOCK_ID + '.inspect'),))
    block = RegisteredBlock(BLOCK_ID, (stage,), ChatGPTPage(page), final=True)
    definition = merge_block_definitions('chatgpt.inspection', 1, (block,))
    return compose_registered_workflow(session=session, ownership=ownership,
        memory=memory, private_inputs=lambda reference: None,
        definition=definition,
        invocations=(BlockInvocation(block, lambda outputs, ctx: EmptyPayload()),),
        workflow_operation_id=workflow_id, allocation=BudgetSpec(10.),
        clock=clock, create_workflow=create)
