"""Compatibility entry for the original offline test command."""
from .tests.test_inspection import InspectionReuseTests
