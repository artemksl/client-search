"""Shared automation components."""
